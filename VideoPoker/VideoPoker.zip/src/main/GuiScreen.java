package main;

public interface GuiScreen {

}
