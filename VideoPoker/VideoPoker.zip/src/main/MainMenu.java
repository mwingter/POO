package main;

public class MainMenu {

}
